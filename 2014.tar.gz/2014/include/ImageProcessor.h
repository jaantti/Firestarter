/* 
 * File:   ImageProcessor.h
 * Author: antti
 *
 * Created on September 7, 2014, 12:24 PM
 */

#ifndef IMAGEPROCESSOR_H
#define	IMAGEPROCESSOR_H

#include "RobotConstants.h"
#include "segmentation.h"
#include "capture.h"
#include "r_video.h"
#include <stdio.h>

class ImageProcessor {
public:
    SEGMENTATION segm;
    ImageProcessor();
    ImageProcessor(const ImageProcessor& orig);
    virtual ~ImageProcessor();
    void init();
};

#endif	/* IMAGEPROCESSOR_H */


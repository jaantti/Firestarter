/* 
 * File:   NetworkConnector.cpp
 * Author: antti
 * 
 * Created on September 7, 2014, 12:25 PM
 */

#include "NetworkConnector.h"

NetworkConnector::NetworkConnector() {
}

NetworkConnector::NetworkConnector(const NetworkConnector& orig) {
}

NetworkConnector::~NetworkConnector() {
}

void NetworkConnector::init() {

}


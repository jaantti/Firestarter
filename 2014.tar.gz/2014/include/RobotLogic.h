/* 
 * File:   RobotLogic.h
 * Author: antti
 *
 * Created on September 7, 2014, 12:24 PM
 */

#ifndef ROBOTLOGIC_H
#define	ROBOTLOGIC_H

#include "RobotConstants.h"

class RobotLogic {

public:
    RobotLogic();
    RobotLogic(const RobotLogic& orig);
    virtual ~RobotLogic();
    void init();
private:

};

#endif	/* ROBOTLOGIC_H */


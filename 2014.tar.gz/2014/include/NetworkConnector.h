/* 
 * File:   NetworkConnector.h
 * Author: noone knows
 *
 * Created on September 7, 2014, 12:25 PM
 */

#ifndef NETWORKCONNECTOR_H
#define	NETWORKCONNECTOR_H

#include "RobotConstants.h"

class NetworkConnector {
public:
    NetworkConnector();
    NetworkConnector(const NetworkConnector& orig);
    virtual ~NetworkConnector();
    void init();
private:

};

#endif	/* NETWORKCONNECTOR_H */


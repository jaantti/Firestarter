/* 
 * File:   RobotConstants.h
 * Author: antti
 *
 * Created on September 7, 2014, 12:26 PM
 */

#ifndef ROBOTCONSTANTS_H
#define	ROBOTCONSTANTS_H

#define NR_OF_WHEELS 3
#define CAMERA_PATH /dev/video0
#define CONF_PATH ../conf
#define CAM_W 640
#define CAM_H 480
#define MAX_MOTOR_SPEED 190


enum RobotStates{
    //TODO populate states
};


#endif	/* ROBOTCONSTANTS_H */


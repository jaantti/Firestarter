/* 
 * File:   ImageProcessor.cpp
 * Author: antti
 * 
 * Created on September 7, 2014, 12:24 PM
 */

#include "ImageProcessor.h"
#include "RobotConstants.h"
#include <cstdlib>
#include <iostream>

ImageProcessor::ImageProcessor()
    : segm(CAM_W, CAM_H) 
{

}

ImageProcessor::ImageProcessor(const ImageProcessor& orig)
    : segm(CAM_W, CAM_H)
{
    
}

ImageProcessor::~ImageProcessor() {
}

void ImageProcessor::init() {
    IMAGE_CONTEXT *video, *thresh;
    IMAGE_CONTEXT *thresholds;
    CAM_SETTINGS cs;
    SUPPORTED_SETTINGS ss;
    CAMERA_CONTROLS cam_ctl[100];
    char menu_names[32][100];
    int cam_ctl_c = 0;
    int menu_c = 0;
    
    open_device( "/dev/video0" );
    init_device( "/dev/video0" );
    
    uchar **fr;
    uchar *frame = NULL;
    get_camera_settings( &cs );
    get_camera_controls( cam_ctl, menu_names, &cam_ctl_c, &menu_c );
    get_supported_settings( cs, &ss );
    readThresholds("conf");
    std::cout << "OH GOD I GOT HERE" << std::endl;
    int gw = cs.width;
    int gh = cs.height;
    start_capturing();
    std::cout << "OH GOD I GOT HERE TOO" << std::endl;
    segm.readThresholds("conf");
    int vx = 627, vy = 282, tx = 1279, ty = 298;
    video = new_window( "Video", vx, vy, gw, gh );
    while(true){
        frame = read_frame();
        std::cout << "Data pointer before handling " << (long) frame << std::endl;
        //std::cout << "HURR3" << std::endl;
        if(frame){
            std::cout << " Print. literally." << std::endl;
            segm.thresholdImage(frame);
            segm.EncodeRuns();
            segm.ConnectComponents();
            segm.ExtractRegions();
            segm.SeparateRegions();
            segm.SortRegions();
            if( strcmp( "YUYV", cs.pix_fmt ) == 0 ) set_working_frame_yuyv( frame, gw, gh);
            fr = get_working_frame();
            
            //show_video(video, fr);
        }
    }
}

/* 
 * File:   RobotLogic.cpp
 * Author: antti
 * 
 * Created on September 7, 2014, 12:24 PM
 */

#include "RobotLogic.h"

RobotLogic::RobotLogic() {
}

RobotLogic::RobotLogic(const RobotLogic& orig) {
}

RobotLogic::~RobotLogic() {
}

void RobotLogic::init() {
 
}
